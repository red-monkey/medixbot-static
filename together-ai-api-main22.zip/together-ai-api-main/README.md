# The Together AI

# The RAG versus LLM branch
This is implemented to use a hybrid system of RAG and LLM to determine the intent of the user when it is not specified as parameter.
It includes building our own RAG Retriever: TogetherRagRetriever

Note: to get realistic results you need to extend the knowledge-base/datasets in the TogetherRagRetriever and also, rewrite the system prompts.  

## Run the RAG 
python3 Rag_vs_LLM.py


## API Functionality Overview

1. Retrieve a list of job positions based on the provided project description. (Redirect to OpenAI)
2. Generate job advertisements tailored to the specified position for recruitment purposes. (Redirect to OpenAI)
3. Compile a list of employees with matching percentages for a given job position using Pinecone:
   - Identify all employees who closely match the job requirements.
   - Optionally, specify the top 'n' employees with the highest matching percentages.
	

## Endpoints::

### -- /chat_ai

For job ads writing, find expert list, get top employee or all employee

     - Type POST
  
     - Example 1: Run Test from command mode using Curl. Command and request example:
        curl -X POST -H "Content-Type: application/json" -d 
        '{
            "text": "find me expert",
            "company":"MeetSimple",
            "source":"Find an expert"
        }' http://localhost:5000/chat_ai

     - Make the command in one line as follows:
        curl -X POST -H "Content-Type: application/json" -d '{"text": "find me expert", "company":"MeetSimple", "source":"Find an expert"}' http://localhost:5000/chat_ai

     - response format:
     {
       "generated_text": "\nIt is not possible to answer this question without prior knowledge of the software job's requirements and Sayali Patil's skills.", 
       "input_text": "Identify all employees by their names whose skills align best with the requirements of the software job.", 
       "intention": "Listing Top Employee Names"
     }

     - Example 2: Run Test from command mode using Curl. Command and request example:
     curl -X POST -H "Content-Type:application/json" -d '{"text":"find me experts","company":"MeetSimple"}' http://localhost:5000/chat_ai

     -response format
        {
        "generated_list": "DevOps Engineer, System Engineer, Cloud Security Professional, Network Engineer, UI/UX Designer, Quality Assurance Specialist.", 
        "generated_text": "I suggest hiring the following personnel to ensure the success of the CloudOptimize project: a DevOps Engineer, a Security Engineer, a Software Engineer, a UI/UX Designer, and an Automation Test Engineer. DevOps can help streamline the development process, while a Security Engineer can provide assurance for data safety. Software Engineers can help build the core product and its features, while a UI/UX Designer ensure the best user experience. Finally, an Automation Test Engineer can ensure proper quality assurance for the software. Together, these personnel can ensure the successful completion of the project.", 
        "input_text": "find me experts", 
        "intention": "Find Experts"
        }

 ### -- /experts
 For Expert Search and Smart Matching
    
     - Type: POST
    
     - Run Test from command mode using Curl. Command and request example:
       curl -X POST -H "Content-Type:application/json" -d '{"domain":"MERN stack developer","company":"MeetSimple"}' http://localhost:5000/experts
    
     - response format example
       {
     "experts_list": "1. Ali Lazim \n2. Sarah Thompson", 
     "input_text": "MERN stack developer", 
     "intention": "Search For Experts"
   }


### -- /set_project
 For setting the current Company

    - Type: POST

	- request format
	   curl -X POST -H "Content-Type: application/json" -d '
		 {
   		  "company":"MeetSimple"	
		  "project": "Project Title: CloudBoost\nDescription:\nWelcome to CloudBoost, the ultimate cloud-based project management solution designed to streamline your workflow and elevate your team's productivity. CloudBoost is a SaaS platform that empowers businesses of all sizes to efficiently manage projects, collaborate seamlessly, and achieve project milestones with ease."}' http://localhost:5000/set_project

	- response format
		 {"response":"success"}

# Important Notes

1) Create .env file and the following;
    MONGO_USERNAME="YOUR_MONGO_USERNAME"
    MONGO_PASSWORD="YOUR_MONGO_PASSWORD"
    HUGGINGFACE_TOKEN="YOUR_HUGGINGFACE_TOKEN"
    OPENAI_API_KEY= "YOUR_OPENAI_API_KEY"

2) Create .gitignore and add the following file and any file that you don't want to commit to the github
   .env
