import os
import re
import json
from flask import Flask, render_template, request, jsonify
from openai import OpenAI
from dotenv import load_dotenv
from urllib.parse import quote_plus

from app_enums import GlobalEnum as GEnum
from app_enums import IntentionEnum as IEnum
from transformers import RagConfig, RagTokenizer, RagSequenceForGeneration
from DContentRagRetriever import DContentRagRetriever
from vector_db import query_vector, create_vector

NUMBER_OF_STARTUP_PROFILE_MISSING_FIELDS_LIMIT = 3
NUMBER_OF_USER_PROFILE_MISSING_FIELDS_LIMIT = 3

# Check if the user and startup profiles are complete and return the missing fields
def check_profiles(user_profile, startup_profile):
    user_profile_missing = []
    startup_profile_missing = []
    
    if user_profile is not None:
        for field in user_profile:
            if user_profile[field] == "":
                user_profile_missing.append(field)
    
    if startup_profile is not None:
        for field in startup_profile:        
            if startup_profile[field] == "":
                startup_profile_missing.append(field)
    
    return user_profile_missing, startup_profile_missing


# Generate a dynamic content using a user input and the dynamic content vector db
def generate_content_with_vectordb(user_profile, startup_profile, requester_page, content):
    
    query = f"{requester_page} {content} "

    user_profile_missing, startup_profile_missing = check_profiles(user_profile, startup_profile)
    print("check_profiles is done...")

    if startup_profile is None or len(startup_profile_missing) > NUMBER_OF_STARTUP_PROFILE_MISSING_FIELDS_LIMIT:
        query += "startup_profile_missing "
    if user_profile is None or len(user_profile_missing) > NUMBER_OF_USER_PROFILE_MISSING_FIELDS_LIMIT:
        query += "user_profile_missing "

    print("calling query_vector...")
    index_name = "dynamic-content"
    dynamic_content = query_vector(index_name, query, 6)
    response_text = "negative"
    if len(dynamic_content) >= 1:
        response_text = "positive"
        dynamic_content = [content.split()[0] for content in dynamic_content if content]

    print("generate_content_with_vectordb = ", response_text, "-" , dynamic_content)
    return response_text, dynamic_content


'''
# RAG setup using the RAG model, RagSequenceForGeneration from Hugging Face
# Create an instance of your custom retriever and pass it to the RagModel
config = RagConfig.from_pretrained("facebook/rag-sequence-nq")
config.index_name = "/Users/a002658/.cache/huggingface"  # the actual path to psgs_w100.tsv.pkl file
rag_tokenizer = RagTokenizer.from_pretrained("facebook/rag-sequence-nq")
rag_model = RagSequenceForGeneration.from_pretrained("facebook/rag-sequence-nq", config=config)
dcontent_retriever = DContentRagRetriever(config, question_encoder_tokenizer=rag_tokenizer, generator_tokenizer=rag_tokenizer)

# Set the retriever for the RagModel
rag_model.set_retriever(dcontent_retriever)

# Determine the intent using RAG
def generate_content_with_rag(user_profile, startup_profile, requester_page, content):
    inputs = rag_tokenizer(user_prompt, return_tensors="pt")
    input_ids = inputs["input_ids"]
    if input_ids is None:
        print("Input IDs is None")
        return None
    else:
        print(f"Input IDs: {input_ids}")
        attention_mask = inputs["attention_mask"]
        generated_ids = rag_model.generator.generate(input_ids=input_ids, attention_mask=attention_mask)   
        if generated_ids is not None:
            intent = rag_tokenizer.generator.decode(generated_ids[0], skip_special_tokens=True)
            return intent
        else:
            print("Generated IDs is None")
            return None
'''