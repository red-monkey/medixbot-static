from langchain import hub
from langchain_pinecone import PineconeVectorStore
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter


def format_docs(docs):
    return "\n\n".join(doc.page_content for doc in docs)

def query_vector(index_name, query):
    embbeding_model =  OpenAIEmbeddings()

    vector_store = PineconeVectorStore.from_existing_index(index_name, embbeding_model)
    retriever = vector_store.as_retriever()
    prompt = hub.pull("rlm/rag-prompt")
    llm = ChatOpenAI(model_name="gpt-3.5-turbo", temperature=0)

    rag_chain = (
        {"context": retriever | format_docs, "question": RunnablePassthrough()}
            | prompt
            | llm
            | StrOutputParser()
    )

    finale_query = query + " .I just want the intention : is it create project, find exapert or suggest tasks?"
    return rag_chain.invoke(finale_query)



if __name__ == "__main__":
    index_name = "nlpsummit"
    query = "create me a project named My startup"
    intentions = query_vector(index_name, query)

    print(intentions)


