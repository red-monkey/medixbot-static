import os
import re
import json
from flask import Flask, render_template, request, jsonify
from openai import OpenAI
from dotenv import load_dotenv
from urllib.parse import quote_plus
from app_enums import GlobalEnum as GEnum
from app_enums import IntentionEnum as IEnum
from util_db import Db
#save_chat_messages, get_chat_messages, get_intentions_and_keywords, get_user_profile, get_startup_profile
from startup_profile import create_startup_profile
from intention_llm_search import find_intention_keyword_match, find_intention_keyword_LLM
from dynamic_content import generate_content_with_vectordb


app = Flask(__name__)
app.secret_key = os.urandom(24) 

# Together API keys
VALID_API_KEYS = os.environ.get("TOGETHER-AI-API-KEY").split(",")

load_dotenv()  # take environment variables from .env. 
api_key = os.environ.get("OPENAI_API_KEY") # the OpenAI API Key 


# The main endpoint for chat: Facilitates natural language conversations and AI interactions.      
#   /chat Parameters: 
#    user_id: Unique identifier for the user.
#    startup_id: Unique identifier for the startup.
#    chat_id: Context identifier within a conversation.
#    context: Free text-based context.
#    user_intention: Explicit intention, if known.
#    user_prompt: Actual user text-based query or request.
#    file: files/documents uploaded with the request.
@app.route("/chat", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        try:
            print("Together AI API: The Chat Endpoint..")

            # Check if the API key is valid and this is an authorized request
            api_key = request.headers.get('TOGETHER-AI-API-KEY')
            if api_key not in VALID_API_KEYS:
                return jsonify({"error": "Unauthorized Access to the Together AI API!"}), 401
            
            user_id = request.form.get('user_id', GEnum.UNDEFINED.name)
            startup_id = request.form.get('startup_id', GEnum.UNDEFINED.name)
            chat_id = request.form.get('conversation_id', GEnum.UNDEFINED.name)
            #context/system_prompt
            context = request.form.get('context', GEnum.UNDEFINED.name)
            user_intention = request.form.get('user_intention', IEnum.UNDEFINED.name)
            user_prompt = request.form.get('user_prompt', GEnum.UNDEFINED.name)
            uploaded_file_text = ""
            if request.files:
                file = request.files['file'] 
                uploaded_file_text = file.read().decode("utf-8")
            
            text_response = "No user prompt provided. Please provide a prompt!"
            options = []
            
            print(f"user_prompt: {user_prompt}")
            if (user_prompt != GEnum.UNDEFINED.name):
                
                final_intention = user_intention
                db = Db()

                # Retrieve existing Chat Thread Messages or create a new one
                chat_thread = []
                chat_messages = []
                user_profile = []
                startup_profile = []

                if (chat_id != GEnum.UNDEFINED.name):
                    chat_thread, chat_messages, user_profile, startup_profile = db.get_chat(chat_id) or []
                    print(f"chat_thread: {chat_thread}")
                    print(f"chat_messages: {chat_messages}")
                    print(f"user_profile: {user_profile}")
                    print(f"startup_profile: {startup_profile}")
                    if ((final_intention == IEnum.UNDEFINED.name) and (chat_thread != None) and (chat_thread["userIntention"] != None)):
                        final_intention = chat_thread["userIntention"]

                if (final_intention == IEnum.UNDEFINED.name):
                    #Retrieve the intensions and their keywords from DB 
                    intentions = db.get_intentions_and_keywords() or []

                    # Method 1: Find Intention Keyword Match & Regex String matching
                    if intentions != []:
                        final_intention = find_intention_keyword_match(context, user_prompt, intentions)
                        print("keyword_match_intention:", final_intention)

                    # Method 2:  AI-based Classification - Find Intention Keyword LLM from enhanced Prompt
                    if final_intention == IEnum.UNDEFINED.name:
                        final_intention = find_intention_keyword_LLM(context, user_prompt, intentions)
                        print("keyword_LLM_intention:", final_intention)
                    
                    # TODO: Method 3:  AI-based Classification - use RAG for enhanced intent determination

                #End if user_intention

                print("Chat Endpoint Intention: ", final_intention)
                match final_intention:
                    case IEnum.CREATE_STARTUP_PROFILE.name:
                        print("Creating a startup profile..")
                        print(f"uploaded_file_text: {uploaded_file_text}")
                        text_response, options = create_startup_profile(startup_id, user_prompt, uploaded_file_text)
                        print(f"text_response: {text_response}")
                        print(f"options: {options}")
                        pass
                    case IEnum.CREATE_PROJECT.name:
                        text_response = create_project()
                        pass
                    case IEnum.SUGGEST_TASKS.name:
                        text_response = suggest_tasks()
                        pass
                    case IEnum.SMART_MATCHING.name:
                        text_response = smart_matching_experts()
                        pass
                    case _:
                        text_response = generic_prompt()

                # Call the parsing function with the response
                #text_response, options = parse_text_and_items(api_output)
                
                # Update the conversation history
                options_str = ' Options: ' + ', '.join(options) if options else ''
                chat_messages.append({"role": "assistant", "content": text_response + options_str})

            data = {
                "text_response": text_response,
                "options": options
            }
            json_data = json.dumps(data)
            #{"text_response": "Here is a startup profile:", 
            #"options": {"name": "My Startup", "industry": "Software", "description": "We make AI products", "team": ""}}
            #return jsonify({"text_response": text_response, "options": options})
            return json_data
            
        except Exception as e:
            print(f"An error occurred: {e}")
            return json.dumps({"error": f"An error occurred: {e}"})
    print("Something went wrong!")
    return json.dumps({"error": "An error occurred while processing your request"})


@app.route("/feedback", methods=["POST"])
def feedback():
    try:
        print("Together AI API: The Feedback Endpoint..")

        # Check if the API key is valid and this is an authorized request
        api_key = request.headers.get('TOGETHER-AI-API-KEY')
        if api_key not in VALID_API_KEYS:
            return jsonify({"error": "Unauthorized Access to the Together AI API!"}), 401
        
        user_id = request.form.get('user_id', GEnum.UNDEFINED.name)
        chat_id = request.form.get('conversation_id', GEnum.UNDEFINED.name)

        feedback_answer = request.form.get('feedbackAnswer')
        feedback_text = request.form.get('feedbackText', '')
        feedback_type = request.form.get('feedbackType', '')

        feedback_entry = {
            "role": "feedback",
            "content": feedback_text,
            "feedback_answer": feedback_answer,
            "feedback_type": feedback_type
        }

        chat_messages = get_chat_messages(user_id, chat_id) or []
        chat_messages.append(feedback_entry)
        save_chat_messages(user_id, chat_id, chat_messages)

        return jsonify({"message": "Feedback received"})
    
    except Exception as e:
        # Log the exception and return an error message
        print(f"An error occurred in feedback route: {e}")
        return jsonify({"error": "An error occurred while processing your feedback"})


@app.route("/get_history", methods=["POST"])
def get_history():
    try:
        print("Together AI API: The Get History Endpoint..")

        # Check if the API key is valid and this is an authorized request
        api_key = request.headers.get('TOGETHER-AI-API-KEY')
        if api_key not in VALID_API_KEYS:
            return jsonify({"error": "Unauthorized Access to the Together AI API!"}), 401
        
        user_id = request.form.get('user_id', GEnum.UNDEFINED.name)
        chat_id = request.form.get('conversation_id', GEnum.UNDEFINED.name)
        chat_messages = get_chat_messages(user_id, chat_id)
        if chat_messages is None:
            chat_messages = []

        # Format the history for display
        formatted_history = ""
        for entry in chat_messages:
            if entry["role"] == "user":
                # Apply blue color style for user prompts
                formatted_history += f'<div style="color: blue;"><strong>{entry["role"].capitalize()}:</strong> {entry["content"]}</div><br>'
            elif entry["role"] == "assistant":
                # Apply black and bold style for AI responses
                formatted_history += f'<div style="color: black;"><strong>{entry["role"].capitalize()}:</strong> {entry["content"]}</div><br><br>'

        return jsonify({"history": formatted_history})
    
    except Exception as e:
        print(f"An error occurred: {e}")
        return jsonify({"error": "An error occurred: {e}"})


# Generates dynamic content based on user and startup status.
#  /dynamic_content Parameters:
#   user_id: Unique identifier for the user.
#   startup_id: Unique identifier for the startup.
#   requester_page: Identifier for the requesting page.
#   content: Specific content identifier for dynamic content generation.
@app.route("/dynamic_content", methods=["GET", "POST"])
def dynamic_content():
    if request.method == "POST":
        try:
            print("Together AI API: The Dynamic Content Endpoint..")

            # Check if the API key is valid and this is an authorized request
            api_key = request.headers.get('TOGETHER-AI-API-KEY')
            if api_key not in VALID_API_KEYS:
                return jsonify({"error": "Unauthorized Access to the Together AI API!"}), 401

            user_id = request.form.get('user_id', GEnum.UNDEFINED.name)
            startup_id = request.form.get('startup_id', GEnum.UNDEFINED.name)
            requester_page = request.form.get('requester_page', GEnum.UNDEFINED.name)
            content = request.form.get('content', GEnum.UNDEFINED.name)
            max_options = int(request.form.get('max_options', "6"))

            text_response = "Wrong or incomplete Request!"
            options = [] 
            
            print(f"requester_page: {requester_page}", f"content: {content}")

            if (requester_page != GEnum.UNDEFINED.name and content != GEnum.UNDEFINED.name):
                
                # Retrieve the User Profile from DB
                db = Db()

                # Retrieve the Startup Profile from DB
                user_profile = None
                if (user_id != GEnum.UNDEFINED.name):
                    user_profile = db.get_user_profile(user_id)

                # Retrieve the Startup Profile from DB
                startup_profile = None
                if (startup_id != GEnum.UNDEFINED.name):
                    startup_profile = db.get_startup_profile(startup_id)
                
                # Generate dynamic content based on user and startup status
                print("calling generate_content_with_vectordb...")
                text_response, options = generate_content_with_vectordb(user_profile, startup_profile, requester_page, content, max_options)
                print(f"text_response: {text_response}")
                print(f"options: {options}") 

            data = {
                "text_response": text_response,
                "options": options
            }
            json_data = json.dumps(data)
            return json_data
            
        except Exception as e:
            print(f"An error occurred: {e}")
            return json.dumps({"error": f"An error occurred: {e}"})
    print("Something went wrong!")
    return json.dumps({"error": "An error occurred while processing your request"})


def parse_response(api_output):
    # Here, you should implement your logic to parse the API response
    # Split the response into text and options (if available)
    #e.g. api_output = "Todo list: | 1:dinner tonight. 2:movie tonight. 3:go for a walk"

    # Placeholder logic: Assuming options are separated by '|' in the response
    parts = api_output.split("|")
    text_response = parts[0].strip()
    options = [option.strip() for option in parts[1:]]
    return text_response, options

"""
Example input_text =
Hello, here are some options for you
1. Have dinner tonight
2. Go see a movie tonight
3. Take a walk around the park
"""
def parse_text_and_items(input_text):   
    # Define a regular expression pattern to match the list of items
    #pattern = r'\d+\.\s+[A-Za-z\s]+'
    pattern = r'\b\d+\.\s+[^\.]+\.'
    
    # Find all matches in the input text
    options = re.findall(pattern, input_text)
    
    # Remove the matches from the input text to get the remaining text
    text_response = re.sub(pattern, '', input_text).strip()
    
    # Remove leading and trailing whitespace
    text_response = re.sub(r'[\r\n]+', '\n', text_response).strip()
    
    # Remove any leading or trailing newline characters
    text_response = text_response.strip('\n')
    
    # Return the text response and the list of items
    return text_response, options


def create_project():
    # Logic for creating a project from NL
    pass


def suggest_tasks():
    # Logic for suggesting possible tasks
    pass


def smart_matching_experts():
    # Logic for smart matching of experts
    pass

def generic_prompt():
    # Logic for generic prompt
    pass

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=80)
