import os
import re
import json
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
from transformers import RagRetriever
import numpy as np

load_dotenv()  # take environment variables from .env.
# the OpenAI API Key
api_key = os.environ.get("OPENAI_API_KEY")

# Initialize LangChain with your LLM API key
chat_llm = ChatOpenAI(api_key=api_key, model="gpt-3.5-turbo-1106")

with open('messages_en.json') as f:
  messages = json.load(f)


class DContentRagRetriever(RagRetriever):
    def __init__(self, config, *args, **kwargs):
        super().__init__(config, *args, **kwargs)
        # Our custom initialization code here
        self.my_dataset = {
            "create_project": "create project",
            "startup_profile": "create startup profile",
            "create_task": "create task",
            "find_expert": "find an expert",
            "other": "Anything else"
        }

    def _build_index(self, *args, **kwargs):
        return None

    def init_retrieval(self):
        pass

    def retrieve(self, user_profile, startup_profile, requester_page, content, n_docs):
        # This is a very naive implementation of the retrieval logic.
        # In a real-world application, you would likely want to use a more sophisticated approach,
        # such as a search engine or a machine learning model.
        
        if isinstance(user_prompt, np.ndarray):
            user_prompt = ' '.join(map(str, user_prompt))
        keywords = user_prompt.split()
        context_texts = [self.my_dataset[keyword] for keyword in keywords if keyword in self.my_dataset]
        return context_texts, None, context_texts
    
