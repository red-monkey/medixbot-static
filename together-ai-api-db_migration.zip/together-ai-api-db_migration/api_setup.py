import sys
from vector_db import create_vector


def initialize(intentions_file:str, index_name: str):
    try:    
        create_vector(intentions_file, index_name)

    except Exception as e:
        print(f"Error: {e}")
        return False

    return True


if __name__ == "__main__":

    completed = True #initialize("data/intentions.txt", "intentions")
    if not completed:
        print("Intentions Initialization failed.. Please try again!")
        sys.exit()

    completed = initialize("data/dynamic_content.txt", "dynamic-content")
    if not completed:
        print("Dynamic Content Initialization failed.. Please try again!")
        sys.exit()
        
    print ("Initialization complete.. You are ready to go!")

