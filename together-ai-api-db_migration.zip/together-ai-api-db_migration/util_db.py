import os
import pymongo
from dotenv import load_dotenv
from urllib.parse import quote_plus
from bson import ObjectId
from app_enums import GlobalEnum as GEnum
from datetime import datetime
from custom_exception import DbConnectionException, DbQueryException
import logging

class Db(object):
    load_dotenv()
    username = quote_plus(os.getenv("MONGO_USERNAME"))
    password = quote_plus(os.getenv("MONGO_PASSWORD"))
    db_name = os.environ.get("DB_NAME") # the MongoDB database name

    def __init__(self):
        self.db = None
        try:
            client = pymongo.MongoClient(f"mongodb+srv://{self.username}:{self.password}@cluster0.ro7v2dq.mongodb.net/?retryWrites=true&w=majority&connectTimeoutMS=60000")
            self.db = client[self.db_name]
            if self.db == None:
                raise DbConnectionException("Db not connected")
        except DbConnectionException as e:
            logging.exception("The DB Connection error is: ", e)


    def get_startup_profile(self, startup_id):
        try:
            startup_profile_collection = self.db.startups
            startup_profile_count =  startup_profile_collection.count_documents({"_id":ObjectId(startup_id)})

            if startup_profile_count == 0 :
                raise DbQueryException("No such startup profile founded.") 
            elif  startup_profile_count > 1:
                raise DbQueryException("Duplicated startup profile detected")
            else:
                return startup_profile_collection.find_one({"_id":ObjectId(startup_id)},{"_id":1,"name":1,"industry":1,"description":1,"team":1,"projects":1})
        except DbQueryException as e:
                logging.exception("Error when querying the Db: ",e)


    def get_user_profile(self, user_id):
        try:
            user_profile_collection = self.db.users
            user_profile_count =  user_profile_collection.count_documents({"_id":ObjectId(user_id)})
            if user_profile_count == 0 :
                raise DbQueryException("No such user profile founded")
            elif user_profile_count > 1 :
                raise DbQueryException("Duplicated user profil detected")
            else:
                return user_profile_collection.find_one({"_id":ObjectId(user_id)},{"_id":1,"firstName":1,"lastName":1,"linkedInID":1,"role":1})
        except DbQueryException as e:
                logging.exception("Error when querying the Db: ",e)


    def _get_chat_messages(self, chat_id):
        try:
            chat_message_collection = self.db.aichatmessages
            chats_count = chat_message_collection.count_documents({"aiChat":ObjectId(chat_id)})
            if chats_count  == 0:
                raise DbQueryException("No such chat founded .")
            else:
                print("_get_chat_messages")
                messages = []
                cursor = chat_message_collection.find({"aiChat":ObjectId(chat_id)},{"_id":1,"aiChat":1,"from":1,"to":1,"content":1,"status":1})
                for message in cursor:
                    print("@@@@ message: ", message)
                    messages.append(message)
                return messages
        except DbQueryException as e:
            logging.exception("Error when querying the db for _get_chat: ",e)


    def _get_chat(self, chat_id):
        try:
            chat_collection  = self.db.aichats
            chat_collection_count =  chat_collection.count_documents({"_id":ObjectId(chat_id)})
            if chat_collection_count  == 0 :
                raise DbQueryException("No such ai chat founded")
            elif chat_collection_count > 1 :
                raise DbQueryException("Duplicated ai chats detected")
            else:
                return chat_collection.find_one({"_id":ObjectId(chat_id)},{"_id":1,"user":1,"startup":1,"userIntention":1})
        except DbQueryException as e:
                logging.exception("Error when querying the Db with _get_chat: ",e)
    

    def get_chat(self, chat_id):
        """TODO: handle the cases keys will not set
        """
        print("get_chat: chat_id: ", chat_id)
        chat_thread         = self._get_chat(chat_id)
        chat_messages       = self._get_chat_messages(chat_id)
        user_profile        = self.get_user_profile(chat_thread["user"])
        startup_profile     = self.get_startup_profile(chat_thread["startup"])

        return chat_thread, chat_messages, user_profile, startup_profile


# TODO: The following function to be removed and replaced with the a function that will handle the Vector DB
def get_intentions_and_keywords(self):
    try:
        intentions_collection = self.db.intentions
        intentions = intentions_collection.find()
        return intentions
    except DbQueryException as e:
                logging.exception("Error when querying the Db while retrieving intentions and keywords: ",e)
    return None
