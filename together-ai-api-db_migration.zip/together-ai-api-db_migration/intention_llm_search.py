import os
import re
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from openai import OpenAI
from dotenv import load_dotenv

from app_enums import GlobalEnum as GEnum
from app_enums import IntentionEnum as IEnum

nltk.download('punkt')
nltk.download('stopwords')

load_dotenv()  # take environment variables from .env. 
api_key = os.environ.get("OPENAI_API_KEY") # the OpenAI API Key 

def preprocess_text(text):
    stemmer = PorterStemmer()
    tokens = word_tokenize(text.lower())
    stemmed = [stemmer.stem(word) for word in tokens if word not in stopwords.words('english')]
    return " ".join(stemmed)

def find_intention_keyword_match(context, prompt, intentions):
    prompt_processed = preprocess_text(prompt)
    context_processed = None
    if context != GEnum.UNDEFINED.name:
        context_processed = preprocess_text(context)
    print("prompt_processed:", prompt_processed)
    for intention_object in intentions:
        intention = intention_object['intention']
        keyword_list = intention_object['keywords']
        # If context directly maps to an intention
        for keyword in keyword_list:
            keyword_processed = preprocess_text(keyword)
            if re.search(r'\b' + re.escape(keyword_processed) + r'\b', prompt_processed):
                return intention
            if (context_processed is not None) and re.search(r'\b' + re.escape(keyword_processed) + r'\b', context_processed):
                return intention
    return GEnum.UNDEFINED.name

def find_intention_keyword_LLM(context, prompt, intentions):
    enhanced_prompt = f"Context: {context}\nUser Prompt: {prompt}\n\n"
    for intention, keywords in intentions.items():
        enhanced_prompt += f"Intention: {intention}, Keywords: {', '.join(keywords)}\n"
    enhanced_prompt += "\nIdentify the specific intention or say UNDEFINED:"

    # Call the OpenAI API
    client = OpenAI(api_key)
    response = client.chat.completions.create(
        messages=enhanced_prompt,
        max_tokens=1000,
        n=1,
        stop=None,
        temperature=0.7,
        model="gpt-3.5-turbo",
    )
    return response.choices[0].message.content.strip()

