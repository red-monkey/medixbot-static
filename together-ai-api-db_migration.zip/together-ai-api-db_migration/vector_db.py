import os
from dotenv import load_dotenv
from langchain_community.document_loaders import TextLoader
from langchain_openai import OpenAIEmbeddings
from langchain_text_splitters import CharacterTextSplitter
from langchain_pinecone import PineconeVectorStore
from pinecone import Pinecone, ServerlessSpec

load_dotenv()  # take environment variables from .env. 
api_key = os.environ.get("OPENAI_API_KEY") # the OpenAI API Key 

def create_vector(intentions_file:str, index_name: str):

    loader = TextLoader(intentions_file)
    documents = loader.load()
    text_splitter = CharacterTextSplitter(chunk_size= 25, separator="\n", chunk_overlap=0)
    docs = text_splitter.split_documents(documents)

    embeddings = OpenAIEmbeddings(api_key=api_key, model="text-embedding-3-small")

    docsearch = PineconeVectorStore.from_documents(docs, embeddings, index_name=index_name)

    return docsearch


def query_vector(index_name, query, k=1):
    embedding_model = OpenAIEmbeddings(api_key=api_key, model="text-embedding-3-small")
    index_search = PineconeVectorStore.from_existing_index(index_name,embedding_model)

    docs_with_scores = index_search.similarity_search_with_score(query)
    top_k_docs_with_scores = docs_with_scores[:k]  # Get the top k documents with scores
    top_k_docs = [doc_with_score[0] for doc_with_score in top_k_docs_with_scores] # Get the document (first element of the tuple) from each tuple
    page_contents = [doc.page_content for doc in top_k_docs]  # Get the page_content of each document

    return page_contents 
