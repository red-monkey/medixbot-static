import os
import pymongo
from dotenv import load_dotenv
from urllib.parse import quote_plus
from bson import ObjectId
from app_enums import GlobalEnum as GEnum

def db_connect():
    load_dotenv()
    username = quote_plus(os.getenv("MONGO_USERNAME"))
    password = quote_plus(os.getenv("MONGO_PASSWORD"))
    db = None
    try:
        client = pymongo.MongoClient(f"mongodb+srv://{username}:{password}@cluster0.ro7v2dq.mongodb.net/?retryWrites=true&w=majority&connectTimeoutMS=60000")
        db = client.togetherdb
    except Exception as e:
        print("The DB Connect error is: ",e)
    return db

def get_intentions_and_keywords():
    db = db_connect()
    if db is not None: 
        try:
            intentions_collection = db.intentions
            intentions = intentions_collection.find()
            return intentions
            """
            intentions_data = {}
            for intention in intentions_collection.find():
                intention_name = intention['intention']
                keywords = intention['keywords']
                intentions_data[intention_name] = keywords
            return intentions_data
            """
        except Exception as e:
            print("Error retrieving intentions and keywords:", e)
    return None

def get_startup_profile(startupid):
    # Logic to retrieve the startup profile from the database
    db = db_connect()
    if db is not None: 
        try:
            startup_profile_collection = db.startups
            startupid_obj = ObjectId(startupid)
            profile = startup_profile_collection.find_one({'_id': startupid_obj})
            if profile:
                print("STARTUP Profile:", profile)
                return profile
            else:
                print("STARTUP Profile: None")
                return None
        except Exception as e:
            print("Error retrieving startup profile from DB:", e)
            return None

def save_startup_profile(startupid, profile):
    # Logic to save or update the startup profile in the database
    db = db_connect()
    if db is not None: 
        try:
            startup_profile_collection = db.startups
            
            # Check if the startup profile is new or already exists
            if startupid is None or startupid == GEnum.UNDEFINED.name:
                startup_profile_collection.insert_one(profile)
                return
            
            startupid_obj = ObjectId(startupid)
            if startup_profile_collection.count_documents({'_id': startupid_obj}) == 0:
                startup_profile_collection.insert_one(profile)
            else:
                startup_profile_collection.update_one({'_id': startupid_obj}, {'$set': profile})
        
        except Exception as e:
            print("Error saving startup profile from DB:", e)


def get_user_profile(userid):
    # Logic to retrieve the startup profile from the database
    db = db_connect()
    if db is not None: 
        try:
            user_profile_collection = db.user
            profile = user_profile_collection.find_one({'_id': userid})
            if profile:
                return profile
            else:
                return None
        except Exception as e:
            print("Error retrieving user profile from DB:", e)
            return None