#!/usr/bin/env python
# -*- coding: utf-8 -*-

class DbConnectionException(Exception):
    pass

class DbQueryException(Exception):
    pass
