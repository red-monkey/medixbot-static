# app_enums.py

from enum import Enum, auto

class GlobalEnum(Enum):
    UNDEFINED = auto()


class IntentionEnum(Enum):
    UNDEFINED = auto()
    CREATE_STARTUP_PROFILE = auto()
    CREATE_FOUNDER_PROFILE = auto()
    CREATE_EXPERT_PROFILE = auto()
    CREATE_INVESTOR_PROFILE = auto()
    CREATE_PROJECT = auto()
    CREATE_TASK = auto()
    SUGGEST_TASKS = auto()
    SMART_MATCHING = auto()
    FIND_EXPERT = auto()
    SMART_NAVIGATION = auto()

class ContentEnum(Enum):
    UNDEFINED = auto()
    FOUNDER_LANDING = auto()
    EXPERT_LANDING = auto()
    INVESTOR_LANDING = auto()

