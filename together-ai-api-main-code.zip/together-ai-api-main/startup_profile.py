import os
import re
import json
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
from util_db import get_startup_profile, save_startup_profile

# Global variable declared 
startup_profile = {}

# Define mandatory fields
mandatory_fields = ['name', 'industry', 'description']
# Define optional fields
optional_fields = ["team", "website", "linkedin", "address", "elevator_pitch"] #"pitch_deck"
# Define all fields
all_fields = mandatory_fields + optional_fields

load_dotenv()  # take environment variables from .env.
# the OpenAI API Key
api_key = os.environ.get("OPENAI_API_KEY")

# Initialize LangChain with your LLM API key
chat_llm = ChatOpenAI(openai_api_key=api_key)

with open('messages_en.json') as f:
  messages = json.load(f)

def create_startup_profile(startup_id, prompt, file_text):
    print(f"create_startup_profile: '{startup_id}', '{prompt}', '{file_text}'")
    # Initialize startup profile data structure
    startup_profile = {
        "name": "",
        "industry": "",
        "description": "",
        "team": "",
        "website": "",
        "linkedin": "",
        "address": "",
        "elevator_pitch": "",
        "pitch_deck": ""
    }

    # Retrieve the Startup Profile from DB
    profile = get_startup_profile(startup_id)
    if profile is not None: 
        startup_profile = profile

    # Extract information from uploaded document
    if file_text != "":
        startup_profile = extract_info_from_document(file_text, startup_profile)

    print(f"startup_profile: {startup_profile}")
    # Extract information from the user prompt document
    startup_profile = extract_info_from_text(prompt, startup_profile)
    
    # Find the missing mandatory and optional information and ask the user for them in the response
    response = gather_missing_info(startup_profile)

    print(startup_profile)
    # Save or update the startup profile in the database
    save_startup_profile(startup_id, startup_profile)

    print(f"response: {response}") 
    startup_profile['_id'] = str(startup_profile['_id'])
    return response, startup_profile


# Extract and collect information from the uploaded document
def extract_info_from_document(file_text, profile):
    profile = extract_info_from_text(file_text, profile)
    return profile

# Extract and collect information from the prompt
def extract_info_from_text(text, profile):
    # Iterate over each information type and extract it using LLM
    for info in all_fields:
        prompt = messages['prompt_startup_profile_extract_info'].format(info=info, text=text) 
        response = chat_llm.invoke(prompt)
        print(response)
       # mylangchain.complete(prompt, max_tokens=100)  # Adjust max_tokens as needed
        extracted_info = response.content.strip()
        
        # Update the profile if valid information is extracted
        if extracted_info and extracted_info != "None":
            profile[info] = extracted_info
    return profile


# Collecting missing information 
def gather_missing_info(profile):
    print("gather_missing_info...")
    man_missing_fields = ""
    opt_missing_fields = ""
    
    print("mandatory_fields...")
    for field in mandatory_fields:
        if not profile.get(field):
            man_missing_fields += f"{field}, "
    
    print("optional_fields...")
    for field in optional_fields:
        if not profile.get(field):
            opt_missing_fields += f"{field}, "
    
    print("resp_text...")
    resp_text = ""
    if man_missing_fields:
        resp_text += messages['prompt_startup_profile_miss_man'].format(man_missing_fields=man_missing_fields[:-1])
    if opt_missing_fields:
        resp_text += messages['prompt_startup_profile_miss_opt'].format(opt_missing_fields=opt_missing_fields[:-1])
    
    if not resp_text:
        resp_text = messages['prompt_startup_profile_done']

    print(f"resp_text = {resp_text}")
    return resp_text


def extract_with_regex(text, pattern):
    match = re.search(pattern, text)
    return match.group(1).strip() if match else ""
