---
name: Story Template
about: Template for Stories (User, Tech, Research, Etc.)
title: ''
labels: ''
assignees: ''

---

## Description

**As a** __
**I want** __
**So that** __

**Notes**
 - 

____________________________

## Acceptance Criteria

###Scenario 1:
**Given**: 
**And**: 
**When**: 
**And**: 
**Then**: 
**And**:
