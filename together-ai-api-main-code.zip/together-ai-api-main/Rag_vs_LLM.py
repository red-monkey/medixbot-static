### This file contains the main API code for the Together AI. 
### It is responsible for processing user input, determining the intent and generating a response, with;
### Master-Agent: generating tasks/subtasks, assigning and administrating;
### Multi-Agents Swarm that run their tasks, and collecting the results from them.
### The API has also a RAG, Cognitive Quest, Short and Long-term memories.. etc.

# Import necessary generic packages
import os
import re
import json
from dotenv import load_dotenv

# Import necessary AI related packages
import torch.utils._pytree
from openai import OpenAI
from transformers import RagConfig, RagTokenizer, RagSequenceForGeneration #, RagRetriever, RagTokenForGeneration

# Import Our Classes and Methods
from MainRagRetriever import TRagRetriever

# Load the .env file
load_dotenv()

# LangChain setup with OpenAI's GPT model or LLaMA or any other model
openai_api_key = os.environ.get("OPENAI_API_KEY")
client = OpenAI(api_key=openai_api_key)

'''
# RAG setup using the RAG model, RagRetriever/RagTokenForGeneration from Hugging Face
rag_tokenizer = RagTokenizer.from_pretrained("facebook/rag-token-nq")
rag_retriever = RagRetriever.from_pretrained("facebook/rag-token-nq", index_name="exact", use_dummy_dataset=False)
rag_model = RagTokenForGeneration.from_pretrained("facebook/rag-token-nq", retriever=rag_retriever)
'''

# RAG setup using the RAG model, RagSequenceForGeneration from Hugging Face
# Create an instance of your custom retriever and pass it to the RagModel
config = RagConfig.from_pretrained("facebook/rag-sequence-nq")
config.index_name = "/Users/a002658/.cache/huggingface"  # the actual path to psgs_w100.tsv.pkl file
rag_tokenizer = RagTokenizer.from_pretrained("facebook/rag-sequence-nq")
rag_model = RagSequenceForGeneration.from_pretrained("facebook/rag-sequence-nq", config=config)
together_retriever = TRagRetriever(config, question_encoder_tokenizer=rag_tokenizer, generator_tokenizer=rag_tokenizer)

# Set the retriever for the RagModel
rag_model.set_retriever(together_retriever)

# Determine the intent using LLM
def determine_intent_with_llm(user_input):
    response = client.chat.completions.create(
                        messages=[{"role": "user", "content": f"Classify the intent of the following user input: '{user_input}'"}],
                        max_tokens=1000,
                        n=1,
                        stop=None,
                        temperature=0.7,
                        model="gpt-3.5-turbo")
    return response.choices[0].message.content.strip()

# Determine the intent using RAG
def determine_intent_with_rag(user_prompt):
    inputs = rag_tokenizer(user_prompt, return_tensors="pt")
    input_ids = inputs["input_ids"]
    if input_ids is None:
        print("Input IDs is None")
        return None
    else:
        print(f"Input IDs: {input_ids}")
        attention_mask = inputs["attention_mask"]
        generated_ids = rag_model.generator.generate(input_ids=input_ids, attention_mask=attention_mask)   
        if generated_ids is not None:
            intent = rag_tokenizer.generator.decode(generated_ids[0], skip_special_tokens=True)
            return intent
        else:
            print("Generated IDs is None")
            return None

# Generate a response using the user input and intent
def generate_response(user_input, intent):
    response = client.chat.completions.create(
                        messages=[{"role": "user", "content": f"Generate a response based on the following user input and intent: '{user_input}', '{intent}'"}],
                        max_tokens=1000,
                        n=1,
                        stop=None,
                        temperature=0.7,
                        model="gpt-3.5-turbo")
    return response.choices[0].message.content.strip()

# Extract information from the user input and information type
def extract_information(user_input, info_type):
    response = client.chat.completions.create(
                        messages=[{"role": "user", "content": f"Extract {info_type} from the following text: '{user_input}'"}],
                        max_tokens=1000,
                        n=1,
                        stop=None,
                        temperature=0.7,
                        model="gpt-3.5-turbo")
    return response.choices[0].message.content.strip()

# Process the user prompt and use a mix of RAG and LLM to determine the intent, extract information and generate a response
def process_user_prompt(user_prompt):
    # Step 1: Use LangChain for initial processing (e.g., getting a basic understanding of the prompt)
    client.chat.completions.create(
                        messages=[{"role": "user", "content": f"Understand the following user prompt: '{user_prompt}'"}],
                        max_tokens=1000,
                        n=1,
                        stop=None,
                        temperature=0.7,
                        model="gpt-3.5-turbo")

    # Step 2: Use RAG for enhanced intent determination
    enhanced_intent = determine_intent_with_rag(user_prompt)

    # Step 3: Generate a response or take action based on the determined intent
    response = client.chat.completions.create(
                        messages=[{"role": "user", "content": f"Generate a response for the intent '{enhanced_intent}' based on the user prompt: '{user_prompt}'"}],
                        max_tokens=1000,
                        n=1,
                        stop=None,
                        temperature=0.7,
                        model="gpt-3.5-turbo")

    return response.choices[0].message.content.strip(), enhanced_intent

# Example usage 1: Determine the intent and generate a response using RAG
user_input = "I want to start a new startup about Software development, Xdavixi."
response, enhanced_intent = process_user_prompt(user_input)
info = extract_information(user_input, "project details")
print("\n\n---------------------------------------------------------------------------------------")
print("Enhanced Intent: ", enhanced_intent, "\n")
print("Response: ", response, "\n")
print("Extracted Information: ", info, "\n")

# Example usage 1: Determine the intent and generate a response using LLM
llm_intent = determine_intent_with_llm(user_input)
response = generate_response(user_input, llm_intent)
info = extract_information(user_input, "project details")
print("\n\n---------------------------------------------------------------------------------------")
print("LLM Intent: ", llm_intent, "\n")
print("Response: ", response, "\n")
print("Extracted Information:", info, "\n")
